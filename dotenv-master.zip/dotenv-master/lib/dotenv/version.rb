module Dotenv
  VERSION = "2.7.6".freeze
end
